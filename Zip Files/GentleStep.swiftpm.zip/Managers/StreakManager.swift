import Foundation

/// Persistence manager for user streaks
class StreakManager {
    static let shared = StreakManager()
    
    private let streakKey = "user_streak_count"
    private let lastCompletionKey = "last_completion_date"
    
    private init() {}
    
    var currentStreak: Int {
        UserDefaults.standard.integer(forKey: streakKey)
    }
    
    func incrementStreak() {
        let today = Calendar.current.startOfDay(for: Date())
        
        if let lastDate = UserDefaults.standard.object(forKey: lastCompletionKey) as? Date {
            let lastDay = Calendar.current.startOfDay(for: lastDate)
            
            // Already completed today
            if Calendar.current.isDate(today, inSameDayAs: lastDay) {
                return
            }
            
            // Check if consecutive
            if let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: today),
               Calendar.current.isDate(lastDay, inSameDayAs: yesterday) {
                UserDefaults.standard.set(currentStreak + 1, forKey: streakKey)
            } else {
                // Streak broken
                UserDefaults.standard.set(1, forKey: streakKey)
            }
        } else {
            // First time
            UserDefaults.standard.set(1, forKey: streakKey)
        }
        
        UserDefaults.standard.set(Date(), forKey: lastCompletionKey)
    }
    
    func resetStreak() {
        UserDefaults.standard.set(0, forKey: streakKey)
        UserDefaults.standard.removeObject(forKey: lastCompletionKey)
    }
}