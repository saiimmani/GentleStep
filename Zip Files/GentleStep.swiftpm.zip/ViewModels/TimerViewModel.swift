import SwiftUI
import Combine

@MainActor
class TimerViewModel: ObservableObject {
    @Published var timeRemaining: TimeInterval = 30.0
    @Published var isActive = false
    @Published var isComplete = false
    @Published var progress: Double = 0.0
    
    private var timer: Timer?
    private let totalDuration: TimeInterval = 30.0
    
    func start() {
        stop()
        
        isActive = true
        isComplete = false
        timeRemaining = totalDuration
        progress = 0.0
        
        timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            
            Task { @MainActor in
                if self.timeRemaining > 0 {
                    self.timeRemaining -= 0.05
                    self.progress = 1.0 - (self.timeRemaining / self.totalDuration)
                    
                    if self.timeRemaining.truncatingRemainder(dividingBy: 10.0) < 0.05 {
                        HapticEngine.shared.lightImpact()
                    }
                } else {
                    self.complete()
                }
            }
        }
    }
    
    func pause() {
        isActive = false
        timer?.invalidate()
        timer = nil
    }
    
    func stop() {
        pause()
        timeRemaining = totalDuration
        progress = 0.0
        isComplete = false
    }
    
    private func complete() {
        isActive = false
        isComplete = true
        timer?.invalidate()
        timer = nil
        progress = 1.0
        HapticEngine.shared.successFeedback()
    }
    
    deinit {
        timer?.invalidate()
    }
}
