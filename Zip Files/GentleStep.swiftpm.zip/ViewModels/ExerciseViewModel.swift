import SwiftUI

@MainActor
class ExerciseViewModel: ObservableObject {
    @Published var selectedExercise: Exercise?
    @Published var isDemoPlaying = false
    @Published var exercises: [Exercise] = Exercise.sampleExercises
    
    func selectExercise(_ exercise: Exercise) {
        selectedExercise = exercise
        HapticEngine.shared.selectionFeedback()
    }
    
    func toggleDemo() {
        isDemoPlaying.toggle()
        HapticEngine.shared.lightImpact()
    }
}
