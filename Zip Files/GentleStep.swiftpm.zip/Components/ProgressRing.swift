import SwiftUI

struct ProgressRing: View {
    let progress: Double
    let isActive: Bool
    
    @State private var animatedProgress: Double = 0
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(LiquidGlass.textLight.opacity(0.3), style: StrokeStyle(lineWidth: 16, lineCap: .round))
            
            Circle()
                .trim(from: 0, to: animatedProgress)
                .stroke(LiquidGlass.softMint, style: StrokeStyle(lineWidth: 16, lineCap: .round))
                .rotationEffect(.degrees(-90))
        }
        .onChange(of: progress) { _, newValue in
            if reduceMotion {
                animatedProgress = newValue
            } else {
                withAnimation(.easeInOut(duration: 0.3)) {
                    animatedProgress = newValue
                }
            }
        }
        .onAppear {
            animatedProgress = progress
        }
    }
}
