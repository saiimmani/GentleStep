import SwiftUI

struct ExerciseAnimatedCharacter: View {
    let animationType: Exercise.AnimationType
    let isPlaying: Bool
    
    @State private var rotation: Double = 0
    @State private var offsetY: CGFloat = 0
    @State private var footAngle: Double = 0
    @State private var circleOffset: CGSize = .zero
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    
    var body: some View {
        ZStack {
            // Shadow that follows body
            Ellipse()
                .fill(Color.black.opacity(0.15))
                .frame(width: 60, height: 20)
                .offset(y: 110 - (offsetY * 0.3))
                .blur(radius: 6)
            
            // Senior figure
            VStack(spacing: 0) {
                // Head (no emoji)
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [LiquidGlass.softPeach, LiquidGlass.softPeachLight],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .frame(width: 35, height: 35)
                    .overlay(
                        Circle()
                            .strokeBorder(LiquidGlass.textSecondary.opacity(0.3), lineWidth: 2)
                    )
                
                // Body (moves with exercises)
                RoundedRectangle(cornerRadius: 10)
                    .fill(
                        LinearGradient(
                            colors: [LiquidGlass.softMint, LiquidGlass.softMintLight],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .frame(width: 45, height: 65)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .strokeBorder(LiquidGlass.textSecondary.opacity(0.3), lineWidth: 2)
                    )
                    .offset(y: -3)
                
                // Legs (move based on exercise)
                legsView
                    .offset(y: -8)
            }
            .offset(x: circleOffset.width, y: circleOffset.height + offsetY)
            
            // Movement indicators
            movementIndicators
        }
        .frame(width: 160, height: 240)
        .onAppear {
            if isPlaying && !reduceMotion {
                startAnimation()
            }
        }
        .onChange(of: isPlaying) { _, newValue in
            if newValue && !reduceMotion {
                startAnimation()
            } else {
                stopAnimation()
            }
        }
    }
    
    // MARK: - Legs View
    
    private var legsView: some View {
        Group {
            switch animationType {
            case .ankleCircles:
                // Legs with rotating ankle/foot
                VStack(spacing: 4) {
                    HStack(spacing: 6) {
                        RoundedRectangle(cornerRadius: 6)
                            .fill(LiquidGlass.textSecondary.opacity(0.5))
                            .frame(width: 15, height: 50)
                        
                        RoundedRectangle(cornerRadius: 6)
                            .fill(LiquidGlass.textSecondary.opacity(0.5))
                            .frame(width: 15, height: 50)
                    }
                    
                    // Rotating foot indicator
                    Capsule()
                        .fill(LiquidGlass.softPeach)
                        .frame(width: 40, height: 15)
                        .rotationEffect(.degrees(rotation))
                }
                
            case .heelRaises:
                // Legs that compress/extend
                HStack(spacing: 6) {
                    RoundedRectangle(cornerRadius: 6)
                        .fill(LiquidGlass.textSecondary.opacity(0.5))
                        .frame(width: 15, height: 50)
                    
                    RoundedRectangle(cornerRadius: 6)
                        .fill(LiquidGlass.textSecondary.opacity(0.5))
                        .frame(width: 15, height: 50)
                }
                
            case .flexPoint:
                // Legs with flexing foot
                VStack(spacing: 4) {
                    HStack(spacing: 6) {
                        RoundedRectangle(cornerRadius: 6)
                            .fill(LiquidGlass.textSecondary.opacity(0.5))
                            .frame(width: 15, height: 50)
                        
                        RoundedRectangle(cornerRadius: 6)
                            .fill(LiquidGlass.textSecondary.opacity(0.5))
                            .frame(width: 15, height: 50)
                    }
                    
                    // Flexing foot
                    Capsule()
                        .fill(LiquidGlass.softPeach)
                        .frame(width: 40, height: 15)
                        .rotationEffect(.degrees(footAngle), anchor: .center)
                }
            }
        }
    }
    
    // MARK: - Movement Indicators
    
    private var movementIndicators: some View {
        Group {
            switch animationType {
            case .ankleCircles:
                // Circular arrow path
                ZStack {
                    Circle()
                        .stroke(LiquidGlass.softMint.opacity(0.3), style: StrokeStyle(lineWidth: 2, dash: [4, 4]))
                        .frame(width: 70, height: 70)
                        .offset(y: 70)
                    
                    Image(systemName: "arrow.clockwise.circle.fill")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(LiquidGlass.softMint)
                        .offset(y: 35)
                    
                    Text("Rotate")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(LiquidGlass.textPrimary)
                        .offset(y: 105)
                }
                
            case .heelRaises:
                // Up/down arrows
                VStack {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(LiquidGlass.softMint)
                        .opacity(offsetY < -15 ? 1.0 : 0.3)
                        .offset(y: -30)
                    
                    Spacer()
                    
                    Image(systemName: "arrow.down.circle.fill")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(LiquidGlass.softPeach)
                        .opacity(offsetY > -15 ? 1.0 : 0.3)
                        .offset(y: 110)
                }
                
            case .flexPoint:
                // Left/right arrows
                HStack {
                    VStack(spacing: 4) {
                        Image(systemName: "arrow.backward.circle.fill")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(LiquidGlass.softMint)
                        Text("Flex")
                            .font(.caption2)
                            .fontWeight(.bold)
                            .foregroundColor(LiquidGlass.textPrimary)
                    }
                    .opacity(footAngle > 0 ? 1.0 : 0.3)
                    .offset(x: -60, y: 70)
                    
                    Spacer()
                    
                    VStack(spacing: 4) {
                        Image(systemName: "arrow.forward.circle.fill")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(LiquidGlass.softPeach)
                        Text("Point")
                            .font(.caption2)
                            .fontWeight(.bold)
                            .foregroundColor(LiquidGlass.textPrimary)
                    }
                    .opacity(footAngle < 0 ? 1.0 : 0.3)
                    .offset(x: 60, y: 70)
                }
            }
        }
    }
    
    // MARK: - Animation Control
    
    private func startAnimation() {
        rotation = 0
        offsetY = 0
        footAngle = 0
        circleOffset = .zero
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            switch self.animationType {
            case .ankleCircles:
                // Rotate foot continuously
                withAnimation(.linear(duration: 3.0).repeatForever(autoreverses: false)) {
                    self.rotation = 360
                }
                // Slight circular body movement
                withAnimation(.easeInOut(duration: 3.0).repeatForever(autoreverses: false)) {
                    self.circleOffset = CGSize(width: 3, height: 3)
                }
                
            case .heelRaises:
                // Body moves up and down
                withAnimation(.easeInOut(duration: 2.0).repeatForever(autoreverses: true)) {
                    self.offsetY = -30
                }
                
            case .flexPoint:
                // Foot flexes back and forth
                withAnimation(.easeInOut(duration: 2.0).repeatForever(autoreverses: true)) {
                    self.footAngle = 30
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    withAnimation(.easeInOut(duration: 2.0).repeatForever(autoreverses: true)) {
                        self.footAngle = -30
                    }
                }
            }
        }
    }
    
    private func stopAnimation() {
        rotation = 0
        offsetY = 0
        footAngle = 0
        circleOffset = .zero
    }
}
