import SwiftUI

struct ExerciseCard: View {
    let exercise: Exercise
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: {
            HapticEngine.shared.selectionFeedback()
            action()
        }) {
            HStack(spacing: LiquidGlass.spacing16) {
                ZStack {
                    Circle()
                        .strokeBorder(isSelected ? LiquidGlass.softMint : LiquidGlass.textLight, lineWidth: 3)
                        .frame(width: 32, height: 32)
                    
                    if isSelected {
                        Circle()
                            .fill(LiquidGlass.softMint)
                            .frame(width: 20, height: 20)
                    }
                }
                
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(isSelected ? LiquidGlass.softMint.opacity(0.2) : LiquidGlass.textLight.opacity(0.1))
                        .frame(width: 56, height: 56)
                    
                    Image(systemName: exercise.animationType.systemImage)
                        .font(.system(size: 24, weight: .semibold))
                        .foregroundColor(isSelected ? LiquidGlass.softMint : LiquidGlass.textSecondary)
                }
                
                VStack(alignment: .leading, spacing: 6) {
                    Text(exercise.name)
                        .font(.body)
                        .fontWeight(.semibold)
                        .foregroundColor(LiquidGlass.textPrimary)
                    
                    Text(exercise.instruction)
                        .font(.caption)
                        .foregroundColor(LiquidGlass.textSecondary)
                        .lineLimit(2)
                }
                
                Spacer()
            }
            .padding(LiquidGlass.spacing16)
            .background(
                RoundedRectangle(cornerRadius: LiquidGlass.radiusMedium)
                    .fill(Color.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: LiquidGlass.radiusMedium)
                            .strokeBorder(isSelected ? LiquidGlass.softMint : Color.clear, lineWidth: 2)
                    )
                    .shadow(color: LiquidGlass.cardShadow(), radius: isSelected ? 12 : 8, x: 0, y: isSelected ? 6 : 4)
            )
        }
        .buttonStyle(GentleButtonStyle())
        .animation(.easeInOut(duration: 0.3), value: isSelected)
    }
}
