import SwiftUI

// Dummy file - not used in app
// Kept for compatibility only

struct GlassButton_Unused: View {
    var body: some View {
        EmptyView()
    }
}
