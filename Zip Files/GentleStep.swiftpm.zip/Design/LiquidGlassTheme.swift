import SwiftUI

struct LiquidGlass {
    // Warm beige background
    static let warmBeige = Color(red: 0.96, green: 0.94, blue: 0.88)
    static let warmBeigeDark = Color(red: 0.92, green: 0.90, blue: 0.85)
    
    // Soft mint accent
    static let softMint = Color(red: 0.65, green: 0.85, blue: 0.75)
    static let softMintLight = Color(red: 0.75, green: 0.90, blue: 0.82)
    
    // Soft peach highlight
    static let softPeach = Color(red: 0.98, green: 0.82, blue: 0.76)
    static let softPeachLight = Color(red: 1.0, green: 0.88, blue: 0.82)
    
    // Text colors
    static let textPrimary = Color(red: 0.25, green: 0.25, blue: 0.25)
    static let textSecondary = Color(red: 0.45, green: 0.45, blue: 0.45)
    static let textLight = Color(red: 0.65, green: 0.65, blue: 0.65)
    
    // Gradients
    static let backgroundGradient = LinearGradient(
        colors: [warmBeige, warmBeigeDark],
        startPoint: .top,
        endPoint: .bottom
    )
    
    // Spacing
    static let spacing4: CGFloat = 4
    static let spacing8: CGFloat = 8
    static let spacing12: CGFloat = 12
    static let spacing16: CGFloat = 16
    static let spacing24: CGFloat = 24
    static let spacing32: CGFloat = 32
    static let spacing48: CGFloat = 48
    static let spacing64: CGFloat = 64
    
    // Corner Radius
    static let radiusSmall: CGFloat = 16
    static let radiusMedium: CGFloat = 20
    static let radiusLarge: CGFloat = 24
    
    // Shadows
    static func cardShadow() -> Color {
        Color.black.opacity(0.08)
    }
}

struct GentleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .opacity(configuration.isPressed ? 0.9 : 1.0)
            .animation(.easeInOut(duration: 0.2), value: configuration.isPressed)
    }
}
