import SwiftUI

/// Calm, restrained animation presets for seniors
struct AnimationStyles {
    
    /// Gentle ease in out (no spring)
    static let gentle = Animation.easeInOut(duration: 0.6)
    
    /// Quick response
    static let quick = Animation.easeInOut(duration: 0.3)
    
    /// Slow and smooth
    static let slow = Animation.easeInOut(duration: 1.0)
    
    /// Continuous slow movement
    static let continuous = Animation.easeInOut(duration: 2.5).repeatForever(autoreverses: true)
    
    /// No animation (for accessibility)
    static let none = Animation.linear(duration: 0)
}
