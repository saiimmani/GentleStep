import SwiftUI

struct CompletionView: View {
    @Environment(\.dismiss) var dismiss
    @State private var opacity: Double = 0
    
    let streak = StreakManager.shared.currentStreak
    
    var body: some View {
        ZStack {
            LiquidGlass.backgroundGradient
                .ignoresSafeArea()
            
            VStack(spacing: LiquidGlass.spacing48) {
                Spacer()
                
                ZStack {
                    Circle()
                        .fill(LiquidGlass.softMint.opacity(0.3))
                        .frame(width: 160, height: 160)
                    
                    Image(systemName: "checkmark")
                        .font(.system(size: 70, weight: .bold))
                        .foregroundColor(LiquidGlass.softMint)
                }
                
                VStack(spacing: LiquidGlass.spacing24) {
                    Text("Well Done!")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(LiquidGlass.textPrimary)
                    
                    Text("You've completed your exercise\nwith care and patience")
                        .font(.title2)
                        .foregroundColor(LiquidGlass.textSecondary)
                        .multilineTextAlignment(.center)
                }
                
                VStack(spacing: LiquidGlass.spacing16) {
                    Text("\(streak)")
                        .font(.system(size: 72, weight: .bold, design: .rounded))
                        .foregroundColor(LiquidGlass.softMint)
                    
                    Text("Day Streak")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(LiquidGlass.textSecondary)
                }
                .padding(LiquidGlass.spacing48)
                .background(
                    RoundedRectangle(cornerRadius: LiquidGlass.radiusLarge)
                        .fill(Color.white)
                        .shadow(color: LiquidGlass.cardShadow(), radius: 12, x: 0, y: 6)
                )
                
                Spacer()
                
                Button(action: {
                    dismiss()
                }) {
                    HStack(spacing: LiquidGlass.spacing12) {
                        Text("Continue")
                            .font(.title2)
                            .fontWeight(.semibold)
                        
                        Image(systemName: "arrow.right")
                            .font(.system(size: 20, weight: .semibold))
                    }
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 64)
                    .background(
                        RoundedRectangle(cornerRadius: LiquidGlass.radiusMedium)
                            .fill(LiquidGlass.softPeach)
                            .shadow(color: LiquidGlass.cardShadow(), radius: 10, x: 0, y: 5)
                    )
                }
                .buttonStyle(GentleButtonStyle())
                .padding(.horizontal, LiquidGlass.spacing24)
                .padding(.bottom, LiquidGlass.spacing32)
            }
            .opacity(opacity)
        }
        .navigationBarBackButtonHidden(true)
        .onAppear {
            withAnimation(.easeInOut(duration: 0.6)) {
                opacity = 1.0
            }
        }
    }
}
