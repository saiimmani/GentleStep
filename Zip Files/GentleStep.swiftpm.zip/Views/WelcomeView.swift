import SwiftUI

struct WelcomeView: View {
    @Binding var showWelcome: Bool
    @State private var opacity: Double = 0
    
    var body: some View {
        ZStack {
            LiquidGlass.backgroundGradient
                .ignoresSafeArea()
            
            VStack(spacing: LiquidGlass.spacing48) {
                Spacer()
                
                ZStack {
                    Circle()
                        .fill(LiquidGlass.softMint.opacity(0.3))
                        .frame(width: 160, height: 160)
                    
                    Image(systemName: "figure.walk")
                        .font(.system(size: 60, weight: .semibold))
                        .foregroundColor(LiquidGlass.softMint)
                }
                
                VStack(spacing: LiquidGlass.spacing24) {
                    Text("GentleStep")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(LiquidGlass.textPrimary)
                    
                    Text("Your gentle path to ankle recovery")
                        .font(.title2)
                        .foregroundColor(LiquidGlass.textSecondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, LiquidGlass.spacing32)
                }
                
                Spacer()
            }
            .opacity(opacity)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 0.6)) {
                opacity = 1.0
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                withAnimation(.easeInOut(duration: 0.6)) {
                    showWelcome = false
                }
            }
        }
    }
}
