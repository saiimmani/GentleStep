import SwiftUI

struct MainTimerView: View {
    @StateObject private var timerVM = TimerViewModel()
    @StateObject private var exerciseVM = ExerciseViewModel()
    @State private var navigateToCompletion = false
    @State private var showWelcome = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                LiquidGlass.backgroundGradient
                    .ignoresSafeArea()
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: LiquidGlass.spacing32) {
                        // Back button
                        HStack {
                            Button(action: {
                                showWelcome = true
                            }) {
                                HStack(spacing: LiquidGlass.spacing8) {
                                    Image(systemName: "chevron.left")
                                        .font(.system(size: 18, weight: .semibold))
                                    Text("Back")
                                        .font(.body)
                                        .fontWeight(.medium)
                                }
                                .foregroundColor(LiquidGlass.softMint)
                                .padding(.horizontal, LiquidGlass.spacing16)
                                .padding(.vertical, LiquidGlass.spacing12)
                                .background(
                                    RoundedRectangle(cornerRadius: LiquidGlass.radiusSmall)
                                        .fill(Color.white)
                                        .shadow(color: LiquidGlass.cardShadow(), radius: 6, x: 0, y: 3)
                                )
                            }
                            .buttonStyle(GentleButtonStyle())
                            
                            Spacer()
                        }
                        .padding(.horizontal, LiquidGlass.spacing24)
                        .padding(.top, LiquidGlass.spacing16)
                        
                        // Header
                        Text("GentleStep")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(LiquidGlass.textPrimary)
                            .padding(.top, LiquidGlass.spacing8)
                        
                        // Timer and Animation side by side
                        HStack(alignment: .top, spacing: LiquidGlass.spacing16) {
                            // Timer on left
                            VStack(spacing: LiquidGlass.spacing16) {
                                ZStack {
                                    ProgressRing(progress: timerVM.progress, isActive: timerVM.isActive)
                                        .frame(width: 200, height: 200)
                                    
                                    VStack(spacing: LiquidGlass.spacing4) {
                                        Text("\(Int(timerVM.timeRemaining))")
                                            .font(.system(size: 56, weight: .bold, design: .rounded))
                                            .foregroundColor(LiquidGlass.textPrimary)
                                            .contentTransition(.numericText())
                                        
                                        Text("seconds")
                                            .font(.body)
                                            .foregroundColor(LiquidGlass.textSecondary)
                                    }
                                }
                                .padding(LiquidGlass.spacing24)
                                .background(
                                    RoundedRectangle(cornerRadius: LiquidGlass.radiusLarge)
                                        .fill(Color.white)
                                        .shadow(color: LiquidGlass.cardShadow(), radius: 12, x: 0, y: 6)
                                )
                                
                                if let exercise = exerciseVM.selectedExercise {
                                    Text(exercise.name)
                                        .font(.body)
                                        .fontWeight(.semibold)
                                        .foregroundColor(LiquidGlass.textPrimary)
                                        .multilineTextAlignment(.center)
                                }
                            }
                            .frame(maxWidth: .infinity)
                            
                            // Animation on right (always playing when exercise selected)
                            if exerciseVM.selectedExercise != nil {
                                VStack(spacing: LiquidGlass.spacing12) {
                                    ExerciseAnimatedCharacter(
                                        animationType: exerciseVM.selectedExercise!.animationType,
                                        isPlaying: true  // Always playing
                                    )
                                    .frame(width: 160, height: 240)
                                    .background(
                                        RoundedRectangle(cornerRadius: LiquidGlass.radiusLarge)
                                            .fill(Color.white)
                                            .shadow(color: LiquidGlass.cardShadow(), radius: 10, x: 0, y: 5)
                                    )
                                    
                                    Text("Animation")
                                        .font(.caption)
                                        .fontWeight(.semibold)
                                        .foregroundColor(LiquidGlass.textSecondary)
                                }
                                .frame(maxWidth: .infinity)
                            }
                        }
                        .padding(.horizontal, LiquidGlass.spacing16)
                        
                        // Control buttons
                        HStack(spacing: LiquidGlass.spacing16) {
                            Button(action: {
                                if exerciseVM.selectedExercise == nil { return }
                                
                                if timerVM.isActive {
                                    timerVM.pause()
                                } else {
                                    timerVM.start()
                                }
                                HapticEngine.shared.mediumImpact()
                            }) {
                                HStack(spacing: LiquidGlass.spacing12) {
                                    Image(systemName: timerVM.isActive ? "pause.fill" : "play.fill")
                                        .font(.system(size: 24, weight: .semibold))
                                    Text(timerVM.isActive ? "Pause" : "Start")
                                        .font(.title2)
                                        .fontWeight(.semibold)
                                }
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .frame(height: 64)
                                .background(
                                    RoundedRectangle(cornerRadius: LiquidGlass.radiusMedium)
                                        .fill(exerciseVM.selectedExercise == nil ? LiquidGlass.textLight : LiquidGlass.softMint)
                                        .shadow(color: LiquidGlass.cardShadow(), radius: 10, x: 0, y: 5)
                                )
                            }
                            .buttonStyle(GentleButtonStyle())
                            .disabled(exerciseVM.selectedExercise == nil)
                            
                            if timerVM.timeRemaining < 30 {
                                Button(action: {
                                    timerVM.stop()
                                    HapticEngine.shared.lightImpact()
                                }) {
                                    Image(systemName: "arrow.clockwise")
                                        .font(.system(size: 24, weight: .semibold))
                                        .foregroundColor(.white)
                                        .frame(width: 64, height: 64)
                                        .background(
                                            RoundedRectangle(cornerRadius: LiquidGlass.radiusMedium)
                                                .fill(LiquidGlass.softPeach)
                                                .shadow(color: LiquidGlass.cardShadow(), radius: 10, x: 0, y: 5)
                                        )
                                }
                                .buttonStyle(GentleButtonStyle())
                                .transition(.opacity)
                            }
                        }
                        .padding(.horizontal, LiquidGlass.spacing24)
                        .animation(.easeInOut(duration: 0.3), value: timerVM.timeRemaining)
                        
                        // Exercise selection
                        VStack(alignment: .leading, spacing: LiquidGlass.spacing24) {
                            Text("Choose Your Exercise")
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(LiquidGlass.textPrimary)
                                .padding(.horizontal, LiquidGlass.spacing24)
                            
                            VStack(spacing: LiquidGlass.spacing16) {
                                ForEach(exerciseVM.exercises) { exercise in
                                    ExerciseCard(
                                        exercise: exercise,
                                        isSelected: exerciseVM.selectedExercise?.id == exercise.id,
                                        action: {
                                            exerciseVM.selectExercise(exercise)
                                        }
                                    )
                                }
                            }
                            .padding(.horizontal, LiquidGlass.spacing24)
                        }
                        
                        // Instructions
                        if let exercise = exerciseVM.selectedExercise {
                            VStack(spacing: LiquidGlass.spacing16) {
                                Text("Instructions")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(LiquidGlass.textPrimary)
                                
                                Text(exercise.instruction)
                                    .font(.body)
                                    .foregroundColor(LiquidGlass.textSecondary)
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal, LiquidGlass.spacing24)
                                    .padding(.vertical, LiquidGlass.spacing16)
                                    .background(
                                        RoundedRectangle(cornerRadius: LiquidGlass.radiusMedium)
                                            .fill(Color.white)
                                            .shadow(color: LiquidGlass.cardShadow(), radius: 8, x: 0, y: 4)
                                    )
                            }
                            .padding(.horizontal, LiquidGlass.spacing24)
                        }
                    }
                    .padding(.bottom, LiquidGlass.spacing48)
                }
            }
            .navigationBarHidden(true)
            .navigationDestination(isPresented: $navigateToCompletion) {
                CompletionView()
            }
            .fullScreenCover(isPresented: $showWelcome) {
                WelcomeView(showWelcome: $showWelcome)
            }
        }
        .onChange(of: timerVM.isComplete) { _, isComplete in
            if isComplete {
                StreakManager.shared.incrementStreak()
                navigateToCompletion = true
            }
        }
    }
}
