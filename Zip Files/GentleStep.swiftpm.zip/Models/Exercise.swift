import Foundation

struct Exercise: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let instruction: String
    let duration: TimeInterval
    let animationType: AnimationType
    
    enum AnimationType: Hashable, CaseIterable {
        case ankleCircles
        case heelRaises
        case flexPoint
        
        var systemImage: String {
            switch self {
            case .ankleCircles: return "arrow.triangle.2.circlepath"
            case .heelRaises: return "arrow.up"
            case .flexPoint: return "arrow.left.and.right"
            }
        }
        
        var guidanceText: String {
            switch self {
            case .ankleCircles: return "Rotate your ankle in smooth circles"
            case .heelRaises: return "Lift your heels up and down slowly"
            case .flexPoint: return "Flex your toes back and point them forward"
            }
        }
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    static func == (lhs: Exercise, rhs: Exercise) -> Bool {
        lhs.id == rhs.id
    }
}

extension Exercise {
    static let sampleExercises: [Exercise] = [
        Exercise(
            name: "Ankle Circles",
            instruction: "Gently rotate your ankle in smooth circular motions. Breathe deeply and move slowly.",
            duration: 30,
            animationType: .ankleCircles
        ),
        Exercise(
            name: "Heel Raises",
            instruction: "Slowly lift your heels off the ground, hold briefly, then lower with control.",
            duration: 30,
            animationType: .heelRaises
        ),
        Exercise(
            name: "Toe Flex & Point",
            instruction: "Point your toes forward, then flex them back toward you. Keep the motion fluid.",
            duration: 30,
            animationType: .flexPoint
        )
    ]
}
