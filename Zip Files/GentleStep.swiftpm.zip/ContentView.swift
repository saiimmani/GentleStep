import SwiftUI

struct ContentView: View {
    @State private var showWelcome = true
    
    var body: some View {
        Group {
            if showWelcome {
                WelcomeView(showWelcome: $showWelcome)
            } else {
                MainTimerView()
            }
        }
    }
}
